#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
@author: HJK
@file: test_main
@time: 2019-01-30
"""
import click
from click.testing import CliRunner
from music_dl import __main__ as m
from music_dl import config


def test_run():
    pass


def test_main():
    pass
