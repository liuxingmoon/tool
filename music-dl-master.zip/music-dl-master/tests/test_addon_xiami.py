#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
@author: HJK
@file: test_addon_xiami.py
@time: 2019-06-13
"""


from music_dl.addons import xiami


# def test_xiami():
#     songs_list = xiami.search("好妹妹乐队")
#     assert songs_list is not None
